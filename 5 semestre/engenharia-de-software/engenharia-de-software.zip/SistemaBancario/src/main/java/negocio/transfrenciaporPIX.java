package negocio;

public class transfrenciaporPIX {

}
